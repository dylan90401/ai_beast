# Dashboard Instructions (apps/dashboard)

### Rules
- Keep dashboard lightweight; avoid heavy deps without approval.
- Any service links must use `PORT_*`.
- Prefer static assets in `apps/dashboard/static/`.
