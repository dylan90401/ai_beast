# Speech API Instructions (apps/speech_api, scripts/96_speech.sh)

### Rules
- Bind to `127.0.0.1` unless LAN is requested.
- Ports must come from `PORT_*`.
- Provide smoke tests + curl verification paths.
