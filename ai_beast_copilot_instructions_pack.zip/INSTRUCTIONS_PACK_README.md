# AI Beast / Kryptos — Copilot Instruction Pack

Contents:
- `.github/copilot-instructions.md` (global rules)
- `.github/instructions/*.instructions.md` (area-specific rules)
- `docs/instructions.md` (human onboarding + buildability contract)
- `Makefile` (optional runner)

How to apply:
1) Unzip into your repo root (it will create/overwrite the files above).
2) Commit `.github/*` and `docs/instructions.md` as you like.
3) Keep `.env` and `config/ports.env` local; never commit secrets.
